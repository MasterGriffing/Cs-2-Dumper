use std::ffi::c_char;

use memflow::prelude::v1::*;

use super::{SchemaClassBinding, SchemaEnumBinding};

use crate::source2::UtlTsHash;

#[derive(Pod)]
#[repr(C)]
pub struct SchemaSystemTypeScope {
    pad_0: [u8; 0x8],                                   // 0x0000
    pub name: [c_char; 256],                            // 0x0008
    pub global_scope: Pointer64<SchemaSystemTypeScope>, // 0x0108
    pad_1: [u8; 0x450],                                 // 0x0110
    pub class_bindings: UtlTsHash<SchemaClassBinding>,  // 0x0560
    pub enum_bindings: UtlTsHash<SchemaEnumBinding>,    // 0x1DD0
}
